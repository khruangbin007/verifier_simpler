#' Loan period in days for an item class
#'
#' @param item_class one of "Standard", "Short" or "Reference"
#' @return the loan period in days
#' @export
loan_days <- function(item_class) {
  periods <- c(Standard = 14, Short = 2, Reference = 0)
  unname(periods[item_class])
}

#' Fine for an overdue item
#'
#' @param days_overdue whole number of days overdue
#' @param item_class one of "Standard", "Short" or "Reference"
#' @param daily_rate rate charged per day
#' @return the fine, capped at eight units
#' @export
fine_due <- function(days_overdue, item_class, daily_rate) {
  free <- if (item_class == "Standard") 2 else 0
  charged <- max(0, days_overdue - free)
  min(charged * daily_rate, 8)
}

#' Whether a loan may be renewed
#'
#' @param item_class one of "Standard", "Short" or "Reference"
#' @param renewals_so_far how many renewals have already been made
#' @param reserved whether another borrower has reserved the item
#' @export
may_renew <- function(item_class, renewals_so_far, reserved) {
  item_class == "Standard" && renewals_so_far < 2 && !reserved
}
