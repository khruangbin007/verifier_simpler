#' Daily rate by item class
#'
#' @format A data frame with 3 rows and 2 columns.
"daily_rates"
