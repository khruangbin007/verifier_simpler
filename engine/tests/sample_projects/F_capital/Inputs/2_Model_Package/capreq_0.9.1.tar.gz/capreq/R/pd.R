#' Floor of the probability of default
#'
#' The probability of default is never taken below 0.03%.
#' @param pd probability of default
#' @param floor the floor, defaults to 0.0003
#' @export
floor_pd <- function(pd, floor = 0.0003) {
  pmax(pd, floor)
}

#' Conditional probability of default
#'
#' Evaluated at the 99.9th percentile of the systematic factor:
#' \deqn{PDc = \Phi\left(\frac{\Phi^{-1}(PD) + \sqrt{\rho} \cdot \Phi^{-1}(0.999)}{\sqrt{1 - \rho}}\right)}
#' @param pd probability of default
#' @param rho asset correlation
#' @param q confidence level, defaults to 0.999
#' @export
cond_pd <- function(pd, rho, q = 0.999) {
  a <- qnorm(pd)
  b <- sqrt(rho) * qnorm(q)
  pnorm((a + b) / sqrt(1 - rho))
}
