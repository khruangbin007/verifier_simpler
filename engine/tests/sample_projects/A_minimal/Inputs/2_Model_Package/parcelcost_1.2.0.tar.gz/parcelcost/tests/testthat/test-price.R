test_that("dimensional weight follows the divisor", {
  expect_equal(dim_weight(50, 40, 30), 12)
})

test_that("the minimum price holds", {
  expect_equal(parcel_price("Local", 0.5), 4.50)
})
