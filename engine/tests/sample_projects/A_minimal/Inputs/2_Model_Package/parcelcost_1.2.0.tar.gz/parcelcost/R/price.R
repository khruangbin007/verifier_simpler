#' Price of a parcel
#'
#' Base rate plus rate per kilogram times chargeable weight, with the fuel surcharge of 12.5%,
#' the volume discount and the minimum price of 4.50.
#' @param zone destination zone: Local, National or Abroad
#' @param cw chargeable weight in kilograms
#' @param n number of parcels handed in at once
#' @export
parcel_price <- function(zone, cw, n = 1) {
  if (!zone %in% zone_rates$zone) stop("unknown zone")
  base <- zone_rates[zone_rates$zone == zone, "base_rate"]
  rate <- zone_rates[zone_rates$zone == zone, "rate_per_kg"]
  price <- base + rate * cw
  with_fuel <- price * (1 + 0.125)
  discounted <- with_fuel * (1 - volume_discount(n))
  round(pmax(discounted, 4.50), 2)
}

#' Volume discount
#'
#' Discount rate of 1% per parcel, capped at 20%.
#' @param n number of parcels handed in at once
#' @export
volume_discount <- function(n) {
  pmin(0.2, 0.01 * n)
}

# Helper used when printing a price list.
format_price <- function(x) {
  paste0(format(x, nsmall = 2), " per parcel")
}
