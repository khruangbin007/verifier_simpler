#' Rates by zone
#'
#' Base rate and rate per kilogram for each destination zone.
#' @format A data frame with 3 rows and 3 columns:
#' \describe{
#'   \item{zone}{destination zone}
#'   \item{base_rate}{base rate per parcel}
#'   \item{rate_per_kg}{rate per kilogram of chargeable weight}
#' }
"zone_rates"
