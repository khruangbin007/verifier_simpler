#' Dimensional weight
#'
#' Weight derived from the volume of a parcel: \deqn{DW = \frac{L \cdot W \cdot H}{5000}}
#' @param l length in centimetres
#' @param w width in centimetres
#' @param h height in centimetres
#' @param divisor the fixed divisor, 5000
#' @export
dim_weight <- function(l, w, h, divisor = 5000) {
  stopifnot(is.numeric(l), is.numeric(w), is.numeric(h))
  l * w * h / divisor
}

#' Chargeable weight
#'
#' The larger of actual weight and dimensional weight, never below 0.5 kilograms.
#' @param aw actual weight in kilograms
#' @param dw dimensional weight in kilograms
#' @export
chargeable_weight <- function(aw, dw) {
  cw <- pmax(aw, dw)
  pmax(cw, 0.5)
}
