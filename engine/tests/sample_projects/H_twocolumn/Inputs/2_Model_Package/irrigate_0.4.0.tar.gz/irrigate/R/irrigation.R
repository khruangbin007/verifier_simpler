#' Volume of water for one bed
#'
#' @param area_m2 the area of the bed in square metres
#' @param crop_group one of "leaf", "root" or "fruiting"
#' @return the volume in litres, capped at two hundred
#' @export
bed_volume <- function(area_m2, crop_group) {
  depths <- c(leaf = 4, root = 6, fruiting = 9)
  min(area_m2 * unname(depths[crop_group]), 200)
}

#' Whether a bed is watered on a given run
#'
#' @param moisture_pct the latest moisture reading, as a percentage
#' @param forecast_mm rain in the forecast, in millimetres
#' @param watered_today whether the bed has already been watered today
#' @export
water_bed <- function(moisture_pct, forecast_mm, watered_today) {
  !watered_today && moisture_pct <= 60 && forecast_mm <= 5
}
