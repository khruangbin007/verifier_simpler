#' Watering depth by crop group
#'
#' @format A data frame with 3 rows and 2 columns.
"crop_depths"
