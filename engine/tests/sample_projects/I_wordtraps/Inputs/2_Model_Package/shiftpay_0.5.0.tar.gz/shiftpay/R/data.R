#' Distance rate by zone
#'
#' @format A data frame with 2 rows and 2 columns.
"zone_rates"
