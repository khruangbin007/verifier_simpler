#' Base pay for a shift
#'
#' @param hours length of the shift in hours
#' @param base_rate pay for one hour
#' @return the base pay, with a minimum of two hours
#' @export
base_pay <- function(hours, base_rate) {
  max(hours, 2) * base_rate
}

#' Distance pay for a shift
#'
#' @param km kilometres ridden
#' @param zone one of "inner" or "outer"
#' @return the distance pay, capped at forty units
#' @export
distance_pay <- function(km, zone) {
  rates <- c(inner = 0.2, outer = 0.4)
  min(km * unname(rates[zone]), 40)
}

#' Night premium on a shift
#'
#' @param base the base pay for the shift
#' @param starts_after_ten whether the shift began after ten at night
#' @export
night_premium <- function(base, starts_after_ten) {
  if (starts_after_ten) base * 0.25 else 0
}
