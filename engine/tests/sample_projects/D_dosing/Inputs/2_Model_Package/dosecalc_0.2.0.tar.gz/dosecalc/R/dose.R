#' Dose by body weight
#'
#' The body weight times the dose rate, never above 4000 milligrams.
#' @param weight body weight in kilograms
#' @param rate dose rate in milligrams per kilogram, defaults to 15
#' @export
dose_by_weight <- function(weight, rate = 15) {
  dose <- weight * rate
  pmin(dose, 4000)
}

#' Dose adjusted for kidney function
#'
#' The dose times the factor of the clearance band, rounded to 10 milligrams.
#' @param dose daily dose in milligrams
#' @param band clearance band: Normal, Reduced or Low
#' @export
adjusted_dose <- function(dose, band) {
  factor <- band_factors[band_factors$band == band, "factor"]
  round(dose * factor / 10) * 10
}
