#' Factors by clearance band
#'
#' @format A data frame with 3 rows and 2 columns:
#' \describe{
#'   \item{band}{clearance band}
#'   \item{factor}{factor applied to the dose}
#' }
"band_factors"
