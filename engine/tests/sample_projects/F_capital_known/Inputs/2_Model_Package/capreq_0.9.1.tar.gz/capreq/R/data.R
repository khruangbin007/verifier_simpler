#' Floors of the loss given default by segment
#'
#' @format A data frame with 3 rows and 2 columns:
#' \describe{
#'   \item{segment}{segment of the exposure}
#'   \item{lgd_floor}{floor of the loss given default}
#' }
#' @source Table 3 of the methodology
"lgd_floors"
