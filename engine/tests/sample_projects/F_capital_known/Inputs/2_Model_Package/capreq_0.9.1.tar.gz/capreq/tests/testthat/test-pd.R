test_that("the floor of the probability of default holds", {
  expect_equal(floor_pd(0.0001), 0.0003)
})

test_that("the conditional probability exceeds the probability", {
  expect_true(cond_pd(0.01, 0.2) > 0.01)
})
