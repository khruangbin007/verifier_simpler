#' Asset correlation
#'
#' The asset correlation falls with the probability of default and lies between 0.12 and 0.24.
#' @param pd probability of default
#' @export
asset_correlation <- function(pd) {
  w <- (1 - exp(-50 * pd)) / (1 - exp(-50))
  0.13 * w + 0.24 * (1 - w)
}
