library(testthat)
library(capreq)
test_check("capreq")
