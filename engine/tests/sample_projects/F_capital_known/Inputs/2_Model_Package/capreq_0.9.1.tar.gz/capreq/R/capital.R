#' Capital requirement per unit of exposure
#'
#' The product of the loss given default, floored by segment, and the unexpected loss rate.
#' @param pd probability of default
#' @param lgd loss given default
#' @param segment segment of the exposure: Retail, Corporate or Bank
#' @export
capital_k <- function(pd, lgd, segment) {
  check_inputs(pd, lgd)
  lgd_f <- pmax(lgd, lgd_floors[lgd_floors$segment == segment, "lgd_floor"])
  pdc <- cond_pd(floor_pd(pd), asset_correlation(pd))
  ul <- pdc - pd
  lgd_f * ul
}

#' Risk-weighted amount
#'
#' The requirement scaled by 12.5 and multiplied by the exposure at default.
#' @param k capital requirement per unit of exposure
#' @param ead exposure at default
#' @export
rwa <- function(k, ead) {
  k * 12.5 * ead
}

#' Effective maturity
#'
#' At least 1 year and capped at 5 years.
#' @param m maturity in years
#' @export
effective_maturity <- function(m) {
  pmin(pmax(m, 1), 5)
}
