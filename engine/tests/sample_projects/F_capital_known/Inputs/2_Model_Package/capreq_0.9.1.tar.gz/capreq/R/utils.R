# Argument checks shared by the exported functions.
check_inputs <- function(pd, lgd) {
  if (!is.numeric(pd)) stop("pd must be numeric")
  if (!is.numeric(lgd)) stop("lgd must be numeric")
  invisible(TRUE)
}

`%||%` <- function(a, b) if (is.null(a)) b else a
