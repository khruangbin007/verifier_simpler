#' Harbour rating
#'
#' The final rating of each harbour, from its factor scores, the factor weights, the adjustments
#' and the anchor rating.
#' @param facilities a data frame of harbours: throughput, berth_utilisation, liquidity_days
#' @param adjustments the names of the adjustments to apply
#' @return the facilities with their final rating
#' @export
harbour_rating <- function(facilities, adjustments = c("size", "governance")) {
  scored <- facilities %>%
    factor_scores() %>%
    dplyr::mutate(base_score = weighted_score(throughput_score, utilisation_score, liquidity_score))
  adjusted <- adjust_score(scored, adjustments)
  anchored <- anchor_rating(adjusted)
  anchored %>% dplyr::mutate(final_rating = cap_rating(anchor, adjusted_score))
}

#' Factor scores
#'
#' Each factor scored from 1 (strongest) to 5 against its thresholds.
#' @param facilities a data frame of harbours
#' @export
factor_scores <- function(facilities) {
  limits <- utils::read.csv(system.file("extdata", "thresholds.csv", package = "harbourscore"))
  facilities %>%
    dplyr::mutate(
      throughput_score = dplyr::case_when(throughput >= limits$high[1] ~ 1, throughput >= limits$low[1] ~ 3, TRUE ~ 5),
      utilisation_score = dplyr::case_when(berth_utilisation <= 0.6 ~ 1, berth_utilisation <= 0.85 ~ 3, TRUE ~ 5),
      liquidity_score = dplyr::if_else(liquidity_days >= 180, 1, 4))
}

#' Weighted score
#'
#' The factor scores weighted by the stored factor weights.
#' @param throughput_score score of the throughput
#' @param utilisation_score score of the berth utilisation
#' @param liquidity_score score of the liquidity
#' @export
weighted_score <- function(throughput_score, utilisation_score, liquidity_score) {
  w <- factor_weights
  w$weight[w$factor == "throughput"] * throughput_score +
    w$weight[w$factor == "utilisation"] * utilisation_score +
    w$weight[w$factor == "liquidity"] * liquidity_score
}

#' Adjusted score
#'
#' The weighted score with the points of each adjustment added.
#' @param scored the scored facilities
#' @param adjustments the names of the adjustments to apply
#' @export
adjust_score <- function(scored, adjustments) {
  steps <- purrr::map_dbl(adjustments, function(name) adjustment_table$points[adjustment_table$adjustment == name])
  scored %>% dplyr::mutate(adjusted_score = base_score + sum(steps))
}

#' Anchor rating
#'
#' The adjusted score rounded to the half point, looked up in the anchor table.
#' @param adjusted the adjusted facilities
anchor_rating <- function(adjusted) {
  adjusted %>%
    dplyr::mutate(score_band = round(adjusted_score * 2) / 2) %>%
    dplyr::left_join(anchor_table, by = "score_band")
}

#' Capped rating
#'
#' A score above 4.5 takes the rating two notches below the anchor.
#' @param anchor the anchor rating
#' @param adjusted_score the adjusted score
cap_rating <- function(anchor, adjusted_score) {
  if (adjusted_score > 4.5) notch_down(anchor, 2) else anchor
}

#' Notch down
#'
#' A rating moved down the rating scale, one notch at a time.
#' @param rating a rating
#' @param n the number of notches
#' @export
notch_down <- function(rating, n) {
  if (n <= 0) return(rating)
  notch_down(rating_scale$rating[match(rating, rating_scale$rating) + 1], n - 1)
}

combine_results <- function(parts) {
  do.call(rbind, parts)
}

legacy_score <- function(x) {
  x * 1.1
}

`%||%` <- function(a, b) if (is.null(a)) b else a
