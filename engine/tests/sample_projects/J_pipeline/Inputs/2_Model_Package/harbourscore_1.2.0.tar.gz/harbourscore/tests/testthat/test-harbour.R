test_that("a strong harbour rates aaa", {
  facilities <- data.frame(throughput = 9e6, berth_utilisation = 0.5, liquidity_days = 200)
  expect_equal(harbour_rating(facilities, character(0))$final_rating, "aaa")
})
